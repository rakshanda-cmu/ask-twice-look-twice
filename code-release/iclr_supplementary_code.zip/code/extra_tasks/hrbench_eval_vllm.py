"""
HR-Bench ordering ablation via the vLLM library.

HR-Bench (Wang et al. 2024) tests fine-grained perception on genuinely
high-resolution images (4K: 4032x4032, 8K: up to 4992x7680) built by pasting
a small target crop into a large distractor canvas -- "Fine-Grained Single
/Cross-instance Perception" (FSP/FCP) categories -- so the model must find
detail that would vanish under naive downscaling.

Source: DreamMr/HR-Bench (HF), hr_bench_4k.parquet + hr_bench_8k.parquet.
Images are base64-encoded JPEG strings (not the HF Image-feature dict used by
CV-Bench/MMStar). "answer" is the bare gold letter A-D.
Metric: multiple-choice exact match on the "(X)" letter, pooled + per-subset
(4k/8k) + per-category.

IMG_CAP is deliberately higher here (2048, vs 1024 elsewhere in this repo)
since downscaling defeats the point of a high-resolution benchmark -- but
full 4032/7680px is still capped to keep Qwen's dynamic-resolution vision
token count within budget (uncapped, an 8K image would blow past
max_model_len).

Run:
  HF_HOME=hf_cache CUDA_VISIBLE_DEVICES=0,1 \
    python extra_tasks/hrbench_eval_vllm.py \
      --orders STI,SIT,STIT,SITIT
"""
import argparse, base64, io, json, os, re, sys, time

SUPP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, SUPP)
from PIL import Image
from common import (ORDER_LIST, ORDER_LETTERS, MODEL_TAG, downscale, data_uri,
                    build_conversation, make_llm, add_echo_args, echo_tag_suffix,
                    echo_occurrence_uris)

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.path.join(HERE, "results")
IMG_CAP = 2048
MC_SUFFIX = "\nAnswer with the option letter in parentheses, e.g. (A)."
LETTER_PAREN = re.compile(r"\(([A-Za-z])\)")


def load_hrbench():
    import pandas as pd
    from huggingface_hub import hf_hub_download
    rows = []
    for subset in ("hr_bench_4k", "hr_bench_8k"):
        p = hf_hub_download("DreamMr/HR-Bench", f"{subset}.parquet", repo_type="dataset")
        df = pd.read_parquet(p)
        for _, r in df.iterrows():
            opts = "\n".join(f"({L}) {r[L]}" for L in ("A", "B", "C", "D")
                             if r.get(L) is not None and str(r[L]) != "nan")
            rows.append({"index": int(r["index"]), "subset": subset,
                        "question": f"{r['question']}\n{opts}",
                        "answer": str(r["answer"]).strip(), "category": r["category"],
                        "image_b64": r["image"]})
    return rows


def parse_letter(text):
    m = LETTER_PAREN.search(text.strip())
    return m.group(1).upper() if m else None


def run_order(llm, sp, tag, letters, rows, log_every, echo_scale=None, echo_which=None):
    out = os.path.join(OUT_DIR, f"hrbench_order-{tag}_{MODEL_TAG}.json")
    if os.path.exists(out):
        try:
            m = json.load(open(out))["meta"]
            if m.get("complete"):
                print(f"  [{tag}] cached (acc={m.get('accuracy'):.3f})", flush=True)
                return
        except Exception:
            pass

    convs = []
    for r in rows:
        img_bytes = base64.b64decode(r["image_b64"])
        pil = downscale(Image.open(io.BytesIO(img_bytes)).convert("RGB"), IMG_CAP)
        task = r["question"] + MC_SUFFIX
        if echo_scale is not None:
            occ_uris = echo_occurrence_uris(pil, echo_scale, echo_which)
            convs.append(build_conversation(letters, task, None,
                                            per_occurrence_uris=occ_uris))
        else:
            convs.append(build_conversation(letters, task, data_uri(pil)))

    t0 = time.time()
    outputs = llm.chat(convs, sp, use_tqdm=False)
    dt = time.time() - t0

    results, n_correct, by_subset = [], 0, {}
    for o, r in zip(outputs, rows):
        text = o.outputs[0].text.strip()
        pred = parse_letter(text)
        gt = r["answer"].upper()
        correct = pred == gt
        n_correct += int(correct)
        bs = by_subset.setdefault(r["subset"], {"n": 0, "correct": 0})
        bs["n"] += 1; bs["correct"] += int(correct)
        results.append({"index": r["index"], "subset": r["subset"],
                        "category": r["category"], "gt": gt, "pred": pred,
                        "raw": text, "correct": correct})
        if len(results) % log_every == 0:
            print(f"    [{tag}] {len(results)}/{len(convs)} "
                  f"acc={n_correct/len(results):.3f}", flush=True)

    by_subset_summary = {s: {"n": v["n"], "accuracy": v["correct"] / v["n"]}
                         for s, v in by_subset.items()}
    meta = {"benchmark": "HR-Bench", "ordering": tag, "model": MODEL_TAG,
            "engine": "vllm", "n": len(results),
            "accuracy": n_correct / max(1, len(results)), "by_subset": by_subset_summary,
            "runtime_s": dt, "complete": True}
    json.dump({"meta": meta, "results": results}, open(out, "w"), indent=2)
    print(f"  [{tag}] n={len(results)} acc={meta['accuracy']:.3f} "
          f"({dt:.0f}s) -> {out}", flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--orders", default=",".join(ORDER_LIST))
    ap.add_argument("--model", default="qwen3-vl-8b",
                    choices=["qwen3-vl-8b", "gemma-3-27b", "gemma-4-31b"])
    ap.add_argument("--tp", type=int, default=2)
    ap.add_argument("--gpu-mem", type=float, default=0.85, dest="gpu_mem",
                    help="vLLM gpu_memory_utilization; lower this if another "
                         "process (e.g. the r1-1.5b server) already holds GPU0.")
    ap.add_argument("--log-every", type=int, default=100, dest="log_every")
    add_echo_args(ap)
    args = ap.parse_args()
    if args.echo_scale is not None and not args.echo_which:
        ap.error("--echo-scale requires --echo-which {first,second}")
    os.makedirs(OUT_DIR, exist_ok=True)

    global MODEL_TAG
    MODEL_TAG = args.model
    if args.model in ("gemma-3-27b", "gemma-4-31b") and args.tp != 1:
        print(f"  [note] forcing --tp 1 for {args.model} (bnb 4-bit, single GPU only)")
        args.tp = 1

    rows = load_hrbench()
    print(f"[data] {len(rows)} HR-Bench rows", flush=True)

    from vllm import SamplingParams
    llm = make_llm(tp=args.tp, model_tag=args.model, gpu_mem=args.gpu_mem)
    sp = SamplingParams(temperature=0.0, max_tokens=256)

    for tag in [o.strip() for o in args.orders.split(",") if o.strip()]:
        if tag not in ORDER_LIST:
            print(f"  skip {tag} (not hook-free)"); continue
        if args.echo_scale is not None:
            assert tag.count("I") == 2, \
                f"--echo-scale requires a 2-image order, got {tag!r}"
            out_tag_name = echo_tag_suffix(tag, args.echo_scale, args.echo_which)
        else:
            out_tag_name = tag
        print(f"=== HR-Bench · ordering {out_tag_name} ===", flush=True)
        run_order(llm, sp, out_tag_name, ORDER_LETTERS[tag], rows, args.log_every,
                  echo_scale=args.echo_scale, echo_which=args.echo_which)
    print("[done]", flush=True)


if __name__ == "__main__":
    main()
